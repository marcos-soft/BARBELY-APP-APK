# Barbely — generar APK en GitHub Actions

## Crear un repositorio nuevo
1. Abre tu repositorio `Barbely-Android` (o el repositorio que usas para generar el APK).
2. Desde el teléfono, sube el archivo `Barbely-Android-Correccion-Correos.zip` a la raíz del repositorio. No hace falta descomprimirlo: el flujo de GitHub Actions ahora reconoce ese ZIP y extrae el proyecto Android nativo automáticamente.
3. Confirma la subida en la rama `main`.
4. Abre la pestaña **Actions** del repositorio. El flujo **Generar APK de Barbely** se ejecuta al subir a `main`; también puedes abrirlo y pulsar **Run workflow**.
5. Espera que la ejecución termine con marca verde. Abre la ejecución y descarga el artefacto `Barbely-APK-Android` de la sección **Artifacts**.
6. Extrae el ZIP del artefacto. `app-debug.apk` es para pruebas. `app-release.apk` también se firma con la clave de depuración según la configuración actual; no es una firma de publicación de Google Play.

## Cambio de correo de los barberos
- Si el gerente modifica el correo de un barbero, ese cambio en Firestore no cambia por sí solo el correo de Firebase Authentication.
- En esta versión, cada barbero debe iniciar sesión con su correo anterior y contraseña actual, abrir **Perfil**, escribir el correo nuevo y confirmar con su contraseña actual.
- La app reautentica al propio barbero, actualiza Firebase Authentication y sincroniza el campo `email` en `usuarios/{uid}` y `barberos/{uid}`. Se conserva el UID y, por tanto, sus citas y horarios.
- El gerente ya no puede editar el correo de acceso desde el formulario de edición; puede cambiarlo el propio barbero desde su perfil.

## Importante
- Este flujo compila los APK; no publica las reglas de Firestore automáticamente.
- La configuración de Firebase apunta al proyecto `barbely-56710` y la app usa el paquete Android `com.barbely.app`.
- La compilación todavía debe comprobarse en GitHub. Si falla, abre el registro de la ejecución y revisa el primer error de Gradle/Kotlin.
- No subas contraseñas, claves privadas ni archivos de firma. No reemplaces el repositorio anterior: este debe ser uno nuevo para mantenerlo separado.
