package com.barbely.app

import android.app.Application
import com.barbely.app.data.FirebaseBackend
import com.barbely.app.data.FirebaseConfig
import com.barbely.app.state.AppState
import com.barbely.app.ui.nav.Navigator
import com.barbely.app.ui.nav.Route
import com.google.firebase.FirebaseApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * El estado vive en la Application para que sobreviva a que Android recree la pantalla
 * (cambio de tema, de tamaño de letra, etc.) sin perder la sesión ni la navegación.
 */
class BarbelyApplication : Application() {

    lateinit var appState: AppState
        private set
    lateinit var navigator: Navigator
        private set

    override fun onCreate() {
        super.onCreate()
        // Si el proyecto incluye app/google-services.json, Firebase ya se inició solo con esos datos.
        // Si no, se conecta al proyecto "barbely-56710" con los datos de FirebaseConfig.
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseApp.initializeApp(this, FirebaseConfig.options())
        }
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        appState = AppState(FirebaseBackend(this), scope)
        // Siempre se arranca en Welcome; BarbelyApp pasa a Inicio en cuanto Firebase confirma la sesión guardada.
        navigator = Navigator(Route.Welcome)
    }
}
