package com.barbely.app.data

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException

/** Traduce los errores de Firebase a mensajes en español para el usuario. */
internal object FirebaseErrors {

    const val NO_CONNECTION = "No hay conexión con Firebase. Revisa Internet."

    const val PERMISSION_DENIED =
        "Firestore rechazó la operación (permiso denegado). Publica las reglas de seguridad del " +
            "proyecto (archivo firebase/firestore.rules, mira el LEEME) o revisa que tu usuario tenga el rol correcto."

    const val SESSION_EXPIRED = "Tu sesión expiró. Inicia sesión de nuevo."

    fun map(error: Throwable): AppException = when (error) {
        is AppException -> error
        is FirebaseAuthException -> auth(error)
        is FirebaseNetworkException -> AppException(NO_CONNECTION)
        is FirebaseTooManyRequestsException ->
            AppException("Demasiados intentos. Intenta nuevamente más tarde.")
        is FirebaseFirestoreException -> firestore(error)
        else -> AppException(fallback(error))
    }

    /** Ejecuta [block] y convierte cualquier error de Firebase en [AppException]. */
    inline fun <T> guard(block: () -> T): T =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: AppException) {
            throw e
        } catch (e: Exception) {
            throw map(e)
        }

    private fun auth(error: FirebaseAuthException): AppException {
        val message = when (error.errorCode) {
            "ERROR_INVALID_EMAIL" -> "El correo electrónico no es válido."
            "ERROR_WRONG_PASSWORD",
            "ERROR_INVALID_CREDENTIAL",
            "ERROR_INVALID_LOGIN_CREDENTIALS" -> "Correo o contraseña incorrectos."
            "ERROR_USER_NOT_FOUND" -> "No existe una cuenta con ese correo."
            "ERROR_USER_DISABLED" -> "Esta cuenta está desactivada."
            "ERROR_EMAIL_ALREADY_IN_USE" -> "Ese correo ya tiene una cuenta."
            "ERROR_WEAK_PASSWORD" -> "La contraseña debe tener al menos 6 caracteres."
            "ERROR_TOO_MANY_REQUESTS" -> "Demasiados intentos. Intenta nuevamente más tarde."
            "ERROR_NETWORK_REQUEST_FAILED" -> NO_CONNECTION
            "ERROR_OPERATION_NOT_ALLOWED" ->
                "El acceso con correo y contraseña no está activado en Firebase " +
                    "(Authentication → Método de acceso → Correo electrónico/contraseña)."
            "ERROR_REQUIRES_RECENT_LOGIN" ->
                "Por seguridad, vuelve a iniciar sesión e inténtalo de nuevo."
            "ERROR_USER_TOKEN_EXPIRED",
            "ERROR_INVALID_USER_TOKEN" -> SESSION_EXPIRED
            else -> fallback(error)
        }
        return AppException(message)
    }

    private fun firestore(error: FirebaseFirestoreException): AppException {
        val detail = error.message.orEmpty()
        val message = when (error.code) {
            FirebaseFirestoreException.Code.PERMISSION_DENIED -> PERMISSION_DENIED
            FirebaseFirestoreException.Code.UNAVAILABLE -> NO_CONNECTION
            FirebaseFirestoreException.Code.UNAUTHENTICATED -> SESSION_EXPIRED
            FirebaseFirestoreException.Code.DEADLINE_EXCEEDED ->
                "Firebase tardó demasiado en responder. Inténtalo de nuevo."
            FirebaseFirestoreException.Code.NOT_FOUND ->
                "No se encontró el registro en Firebase (puede que ya no exista)."
            FirebaseFirestoreException.Code.ABORTED ->
                "Otro usuario modificó los datos al mismo tiempo. Inténtalo de nuevo."
            FirebaseFirestoreException.Code.RESOURCE_EXHAUSTED ->
                "Se superó la cuota gratuita de Firebase. Inténtalo más tarde."
            FirebaseFirestoreException.Code.INVALID_ARGUMENT ->
                if (detail.contains("longer than", ignoreCase = true) || detail.contains("exceeds", ignoreCase = true)) {
                    "La imagen es demasiado pesada para guardarse. Elige una más pequeña."
                } else {
                    "Firestore rechazó los datos: $detail"
                }
            else -> "Error de Firestore (${error.code}): $detail"
        }
        return AppException(message)
    }

    private fun fallback(error: Throwable): String {
        val detail = error.message?.takeIf { it.isNotBlank() }
        return if (detail != null) "Error de Firebase: $detail" else "Ocurrió un error inesperado."
    }
}
