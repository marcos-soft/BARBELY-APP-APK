package com.barbely.app.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.barbely.app.data.AppException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Ejecuta las operaciones con Firebase que lanzan los botones (guardar, reservar, cancelar...).
 *
 *  - [running] es true mientras la operación está en curso: úsalo para mostrar el círculo de carga
 *    en el botón (`loading = action.running`).
 *  - Mientras hay una operación en curso, otro toque no hace nada (evita guardar dos veces).
 *  - Si la operación falla, [run] llama a `onError` con el mensaje en español.
 */
@Stable
class ActionRunner(private val scope: CoroutineScope) {

    var running by mutableStateOf(false)
        private set

    fun run(onError: (String) -> Unit = {}, block: suspend () -> Unit) {
        if (running) return
        running = true
        scope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: AppException) {
                onError(e.message ?: GENERIC_ERROR)
            } catch (e: Exception) {
                onError(e.message?.takeIf { it.isNotBlank() }?.let { "Ocurrió un error: $it" } ?: GENERIC_ERROR)
            } finally {
                running = false
            }
        }
    }

    private companion object {
        const val GENERIC_ERROR = "Ocurrió un error inesperado. Inténtalo de nuevo."
    }
}

@Composable
fun rememberActionRunner(): ActionRunner {
    val scope = rememberCoroutineScope()
    return remember(scope) { ActionRunner(scope) }
}
