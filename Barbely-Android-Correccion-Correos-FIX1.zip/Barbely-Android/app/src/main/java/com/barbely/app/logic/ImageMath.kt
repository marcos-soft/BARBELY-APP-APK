package com.barbely.app.logic

/**
 * Cálculos puros (sin Android) para preparar las fotos de los servicios antes de guardarlas en
 * Firestore. Un documento de Firestore admite como máximo 1 MiB, así que la foto se reduce a
 * 800 px de lado mayor y se comprime a JPEG por debajo de ~300 KB (≈ 400 KB en Base64).
 */
const val IMAGE_MAX_SIDE = 800
const val IMAGE_MAX_BYTES = 300_000
const val IMAGE_START_QUALITY = 82
const val IMAGE_MIN_QUALITY = 50
const val IMAGE_MIN_SIDE = 360

/**
 * Mayor potencia de 2 que se puede usar como `inSampleSize` al decodificar sin que el lado mayor
 * quede por debajo de [targetSide] (así se ahorra memoria con fotos de 12 MP o más).
 */
fun computeSampleSize(width: Int, height: Int, targetSide: Int): Int {
    var sample = 1
    val longest = maxOf(width, height)
    while (longest / (sample * 2) >= targetSide) sample *= 2
    return sample
}

/** Tamaño final manteniendo la proporción, con el lado mayor <= [maxSide] (nunca agranda). */
fun fitWithin(width: Int, height: Int, maxSide: Int): Pair<Int, Int> {
    val longest = maxOf(width, height)
    if (longest <= maxSide) return width to height
    val scale = maxSide.toDouble() / longest
    val w = maxOf(1, Math.round(width * scale).toInt())
    val h = maxOf(1, Math.round(height * scale).toInt())
    return w to h
}

/** Transformación que corrige la orientación EXIF: primero girar [rotation] grados y luego, si hace falta, espejar. */
data class ExifTransform(val rotation: Float, val flipHorizontal: Boolean) {
    val isIdentity: Boolean get() = rotation == 0f && !flipHorizontal
}

/** Valores de android.media.ExifInterface.ORIENTATION_*: 1 normal, 2 espejo, 3 giro 180, 4 espejo vertical, 5 transpuesta, 6 giro 90, 7 transversal, 8 giro 270. */
fun exifTransform(orientation: Int): ExifTransform = when (orientation) {
    2 -> ExifTransform(0f, true)
    3 -> ExifTransform(180f, false)
    4 -> ExifTransform(180f, true)
    5 -> ExifTransform(90f, true)
    6 -> ExifTransform(90f, false)
    7 -> ExifTransform(270f, true)
    8 -> ExifTransform(270f, false)
    else -> ExifTransform(0f, false)
}

private const val DATA_URI_PREFIX = "data:image/jpeg;base64,"

fun toDataUri(base64Jpeg: String): String = DATA_URI_PREFIX + base64Jpeg

/** Parte Base64 de un "data:image/...;base64,XXXX" (null si no es una imagen incrustada). */
fun dataUriPayload(source: String): String? {
    if (!source.startsWith("data:image")) return null
    val comma = source.indexOf(',')
    if (comma < 0 || comma + 1 >= source.length) return null
    val header = source.substring(0, comma)
    if (!header.contains("base64", ignoreCase = true)) return null
    return source.substring(comma + 1)
}

/** Solo se aceptan enlaces https (Android bloquea el tráfico http sin cifrar). */
fun isRemoteImage(source: String): Boolean =
    source.startsWith("https://", ignoreCase = true) || source.startsWith("http://", ignoreCase = true)
