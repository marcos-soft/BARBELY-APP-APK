package com.barbely.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType

enum class ButtonVariant { Primary, Secondary, Ghost, Danger }

/** Botón con 4 variantes (equivale a ui/Button.tsx). */
@Composable
fun BButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: ButtonVariant = ButtonVariant.Primary,
    enabled: Boolean = true,
    loading: Boolean = false,
    icon: Int? = null,
    fullWidth: Boolean = true,
) {
    val isDisabled = !enabled || loading
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val shape = RoundedCornerShape(BRadius.sm)

    val container: Color
    val pressedContainer: Color
    val labelColor: Color
    when (variant) {
        ButtonVariant.Primary -> {
            container = BColors.gold
            pressedContainer = BColors.goldPressed
            labelColor = BColors.onGold
        }
        ButtonVariant.Secondary -> {
            container = Color.Transparent
            pressedContainer = BColors.surfaceElevated
            labelColor = BColors.gold
        }
        ButtonVariant.Ghost -> {
            container = Color.Transparent
            pressedContainer = BColors.surface
            labelColor = BColors.textPrimary
        }
        ButtonVariant.Danger -> {
            container = BColors.danger
            pressedContainer = BColors.dangerPressed
            labelColor = BColors.white
        }
    }
    val background = if (pressed && !isDisabled) pressedContainer else container

    Box(
        modifier = modifier
            .then(if (fullWidth) Modifier.fillMaxWidth() else Modifier)
            .alpha(if (isDisabled) 0.45f else 1f)
            .heightIn(min = 52.dp)
            .clip(shape)
            .background(background, shape)
            .then(
                if (variant == ButtonVariant.Secondary) {
                    Modifier.border(1.5.dp, BColors.gold, shape)
                } else {
                    Modifier
                },
            )
            .clickable(
                interactionSource = source,
                indication = null,
                enabled = !isDisabled,
                onClick = onClick,
            )
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                color = labelColor,
                strokeWidth = 2.dp,
            )
        } else {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (icon != null) BIcon(icon, 18.dp, labelColor)
                BText(label, BType.button, labelColor)
            }
        }
    }
}
