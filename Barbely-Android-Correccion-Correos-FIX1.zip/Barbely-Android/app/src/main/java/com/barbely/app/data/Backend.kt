package com.barbely.app.data

/** Cancela una suscripción (por ejemplo, quita una escucha en tiempo real). */
typealias Stop = () -> Unit

/** Datos para crear una cita nueva. */
data class NewAppointment(
    val cliente: User,
    val barberoId: String,
    val servicioId: String,
    val fecha: String,
    val horaInicio: String,
    val horaFin: String,
    val duracionMinutos: Int,
    val precio: Double,
)

data class ServiceInput(
    val nombre: String,
    val descripcion: String?,
    val precio: Double,
    val duracion: Int,
    val imagen: String?,
    val activo: Boolean,
)

data class BarberInput(
    val nombre: String,
    val especialidad: String,
    val descripcion: String?,
    val activo: Boolean,
    val email: String?,
)

/**
 * Todo lo que la app necesita del servidor. La implementación real es [FirebaseBackend]
 * (Firebase Authentication + Cloud Firestore, el mismo proyecto de la app original).
 *
 * Reglas del contrato:
 *  - Las funciones `suspend` lanzan [AppException] con un mensaje en español listo para mostrar.
 *  - Las escuchas (`listen...`) entregan la lista completa cada vez que algo cambia, en el hilo principal.
 */
interface Backend {

    // ------------------------------------------------------------------
    // Autenticación
    // ------------------------------------------------------------------

    /** Uid de la sesión de Firebase en este momento (null si no hay sesión). */
    val currentUid: String?

    /** Avisa con el uid de la sesión de Firebase (o null si no hay sesión) al registrarse y cada vez que cambia. */
    fun listenAuth(onChange: (uid: String?) -> Unit): Stop

    /** Inicia sesión y devuelve el uid. */
    suspend fun signIn(email: String, password: String): String

    /** Crea la cuenta de acceso (sin perfil) y deja la sesión abierta. Devuelve el uid. */
    suspend fun signUp(nombre: String, email: String, password: String): String

    suspend fun sendPasswordReset(email: String)

    /** Actualiza el correo de la cuenta autenticada tras confirmar su contraseña actual. */
    suspend fun updateOwnEmail(newEmail: String, currentPassword: String)

    /** Cierra la sesión de Firebase. */
    fun signOut()

    /** Vuelve a verificar la contraseña de la sesión actual (necesario antes de borrar la cuenta). */
    suspend fun reauthenticate(password: String)

    /** Borra la cuenta de acceso de la sesión actual. */
    suspend fun deleteAuthAccount()

    /**
     * Crea la cuenta de acceso de un barbero SIN cerrar la sesión del gerente (usa una segunda
     * instancia de Firebase). Devuelve el uid de la cuenta nueva.
     */
    suspend fun createStaffAccount(email: String, password: String): String

    // ------------------------------------------------------------------
    // Perfil de usuario (colección "usuarios")
    // ------------------------------------------------------------------

    /** Lee el perfil; si no existe lo crea como cliente (igual que la app original). */
    suspend fun loadUser(uid: String): User

    /** Crea el perfil de un cliente recién registrado. */
    suspend fun createClientProfile(uid: String, nombre: String, email: String): User

    suspend fun updateUserProfile(uid: String, nombre: String, telefono: String?)

    suspend fun deleteUserProfile(uid: String)

    // ------------------------------------------------------------------
    // Escuchas en tiempo real
    // ------------------------------------------------------------------

    fun listenServices(onData: (List<Service>) -> Unit, onError: (AppException) -> Unit): Stop

    fun listenBarbers(onData: (List<Barber>) -> Unit, onError: (AppException) -> Unit): Stop

    fun listenSchedules(onData: (List<Schedule>) -> Unit, onError: (AppException) -> Unit): Stop

    /** Gerente: todas las citas. Barbero: las suyas. Cliente: las suyas. */
    fun listenAppointments(user: User, onData: (List<Appointment>) -> Unit, onError: (AppException) -> Unit): Stop

    /** Horarios ocupados desde [fromDate] ("YYYY-MM-DD") en adelante. */
    fun listenBlocks(fromDate: String, onData: (List<Bloqueo>) -> Unit, onError: (AppException) -> Unit): Stop

    // ------------------------------------------------------------------
    // Escrituras
    // ------------------------------------------------------------------

    suspend fun saveService(id: String?, input: ServiceInput)

    suspend fun setServiceActive(id: String, activo: Boolean)

    /** Crea el perfil de un barbero (usuario con rol "barbero" + documento en "barberos") con el uid ya creado. */
    suspend fun createBarber(uid: String, input: BarberInput)

    suspend fun updateBarber(id: String, input: BarberInput)

    suspend fun setBarberActive(id: String, activo: Boolean)

    /** Lo que el propio barbero puede editar de su perfil. */
    suspend fun updateBarberProfile(id: String, especialidad: String, descripcion: String?)

    /**
     * Deja los horarios del barbero exactamente como están en [drafts] y devuelve el resultado final
     * (con los ids de los bloques nuevos). [current] son los bloques que existen ahora.
     */
    suspend fun saveSchedules(barberoId: String, current: List<Schedule>, drafts: List<ScheduleDraft>): List<Schedule>

    /**
     * Crea la cita y sus bloqueos de forma atómica. Si algún bloqueo ya existe lanza
     * [AppException] "Ese horario ya fue ocupado. Elige otro." y no guarda nada.
     */
    suspend fun createAppointment(data: NewAppointment): Appointment

    /** Cambia el estado de la cita y, si se cancela, libera sus bloqueos ([release]) en la misma operación. */
    suspend fun setAppointmentStatus(id: String, estado: AppointmentStatus, release: List<Bloqueo>)
}
