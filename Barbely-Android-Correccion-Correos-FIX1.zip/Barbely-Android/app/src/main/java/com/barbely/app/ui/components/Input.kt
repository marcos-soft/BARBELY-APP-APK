package com.barbely.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType

/** Campo de texto con etiqueta, ícono, error y ver/ocultar contraseña (equivale a ui/Input.tsx). */
@Composable
fun BInput(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    placeholder: String? = null,
    error: String? = null,
    secure: Boolean = false,
    leftIcon: Int? = null,
    keyboardType: KeyboardType = KeyboardType.Text,
    capitalization: KeyboardCapitalization = KeyboardCapitalization.Sentences,
    imeAction: ImeAction = ImeAction.Default,
    multiline: Boolean = false,
    maxLength: Int? = null,
) {
    var focused by remember { mutableStateOf(false) }
    var hidden by remember { mutableStateOf(secure) }
    val shape = RoundedCornerShape(BRadius.sm)
    val borderColor = when {
        error != null -> BColors.danger
        focused -> BColors.gold
        else -> BColors.border
    }

    Column(modifier = modifier.fillMaxWidth().padding(bottom = 16.dp)) {
        if (label != null) {
            BText(label, BType.label, BColors.textSecondary, Modifier.padding(bottom = 4.dp))
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp)
                .background(BColors.surface, shape)
                .border(1.dp, borderColor, shape)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (leftIcon != null) BIcon(leftIcon, 18.dp, BColors.textMuted)
            Box(modifier = Modifier.weight(1f).padding(vertical = 12.dp)) {
                if (value.isEmpty() && placeholder != null) {
                    BText(placeholder, BType.body, BColors.textMuted)
                }
                BasicTextField(
                    value = value,
                    onValueChange = { text ->
                        if (maxLength == null || text.length <= maxLength) onValueChange(text)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .onFocusChanged { state -> focused = state.isFocused },
                    textStyle = BType.body.copy(color = BColors.textPrimary),
                    cursorBrush = SolidColor(BColors.gold),
                    singleLine = !multiline,
                    visualTransformation = if (secure && hidden) {
                        PasswordVisualTransformation()
                    } else {
                        VisualTransformation.None
                    },
                    keyboardOptions = KeyboardOptions(
                        capitalization = capitalization,
                        keyboardType = keyboardType,
                        imeAction = imeAction,
                    ),
                )
            }
            if (secure) {
                Box(modifier = Modifier.tappable { hidden = !hidden }) {
                    BIcon(
                        icon = if (hidden) BIcons.Eye else BIcons.EyeOff,
                        size = 19.dp,
                        tint = BColors.textMuted,
                    )
                }
            }
        }
        if (error != null) {
            BText(error, BType.caption, BColors.danger, Modifier.padding(top = 4.dp))
        }
    }
}
