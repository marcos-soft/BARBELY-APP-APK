package com.barbely.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BType

/** Encabezado de las pantallas internas: botón atrás, título centrado y acción opcional (components/Header.tsx). */
@Composable
fun BHeader(
    title: String,
    showBack: Boolean = true,
    rightIcon: Int? = null,
    onRightClick: (() -> Unit)? = null,
) {
    val nav = LocalNav.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .heightIn(min = 52.dp)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(modifier = Modifier.width(40.dp), contentAlignment = Alignment.CenterStart) {
            if (showBack) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(BColors.surface, CircleShape)
                        .tappable { nav.pop() },
                    contentAlignment = Alignment.Center,
                ) {
                    BIcon(BIcons.ChevronBack, 22.dp, BColors.textPrimary)
                }
            }
        }
        BText(
            text = title,
            style = BType.h3,
            color = BColors.textPrimary,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Box(modifier = Modifier.width(40.dp), contentAlignment = Alignment.CenterEnd) {
            if (rightIcon != null) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(BColors.surface, CircleShape)
                        .tappable { onRightClick?.invoke() },
                    contentAlignment = Alignment.Center,
                ) {
                    BIcon(rightIcon, 20.dp, BColors.textPrimary)
                }
            }
        }
    }
}

data class TabItem(val label: String, val icon: Int)

/** Barra de pestañas inferior. */
@Composable
fun BottomTabBar(items: List<TabItem>, selected: Int, onSelect: (Int) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().background(BColors.backgroundElevated)) {
        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(BColors.borderSubtle))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 8.dp),
        ) {
            items.forEachIndexed { index, item ->
                val tint = if (index == selected) BColors.gold else BColors.textMuted
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .tappable { onSelect(index) }
                        .padding(vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    BIcon(item.icon, 24.dp, tint)
                    BText(
                        text = item.label,
                        style = BType.captionMedium.copy(fontSize = 11.sp),
                        color = tint,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}
