package com.barbely.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BRadius

/** Tarjeta estática: fondo, borde y esquinas redondeadas (equivale a ui/Card.tsx). */
@Composable
fun BCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(BRadius.lg),
    color: Color = BColors.surface,
    borderColor: Color = BColors.borderSubtle,
    borderWidth: Dp = 1.dp,
    elevation: Dp = 0.dp,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier
            .then(if (elevation > 0.dp) Modifier.shadow(elevation, shape) else Modifier)
            .background(color, shape)
            .border(borderWidth, borderColor, shape),
    ) {
        content()
    }
}

/** Tarjeta presionable: cambia de color mientras se mantiene el dedo encima. */
@Composable
fun PressableCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(BRadius.lg),
    color: Color = BColors.surface,
    pressedColor: Color = BColors.surfaceElevated,
    borderColor: Color = BColors.borderSubtle,
    borderWidth: Dp = 1.dp,
    elevation: Dp = 0.dp,
    content: @Composable () -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    Box(
        modifier = modifier
            .then(if (elevation > 0.dp) Modifier.shadow(elevation, shape) else Modifier)
            .background(if (pressed) pressedColor else color, shape)
            .border(borderWidth, borderColor, shape)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
    ) {
        content()
    }
}
