package com.barbely.app.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BHeader
import com.barbely.app.ui.components.BIcon
import com.barbely.app.ui.components.BInput
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.ButtonVariant
import com.barbely.app.ui.components.rememberActionRunner
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BType

/**
 * Recuperar contraseña: Firebase Authentication envía un correo con un enlace para crear una
 * contraseña nueva (igual que en la app original).
 */
@Composable
fun ForgotPasswordScreen() {
    val app = LocalApp.current
    val nav = LocalNav.current
    var email by remember { mutableStateOf("") }
    var formError by remember { mutableStateOf<String?>(null) }
    var sentTo by remember { mutableStateOf<String?>(null) }
    val action = rememberActionRunner()

    fun submit() {
        formError = null
        if (email.trim().isEmpty()) {
            formError = "Escribe tu correo electrónico."
            return
        }
        action.run(onError = { formError = it }) {
            app.resetPassword(email.trim())
            sentTo = email.trim()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .navigationBarsPadding()
            .imePadding(),
    ) {
        BHeader(title = "Recuperar contraseña")
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 24.dp, end = 24.dp, top = 20.dp, bottom = 24.dp),
        ) {
            val sent = sentTo
            if (sent != null) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(top = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .padding(bottom = 12.dp)
                            .size(64.dp)
                            .background(BColors.successBg, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        BIcon(BIcons.Checkmark, 28.dp, BColors.success)
                    }
                    BText("Revisa tu correo", BType.h1, BColors.textPrimary, textAlign = TextAlign.Center)
                    BText(
                        text = "Si existe una cuenta con $sent, te enviamos un correo con un enlace para crear una " +
                            "contraseña nueva. Revisa también la carpeta de spam.",
                        style = BType.body,
                        color = BColors.textSecondary,
                        modifier = Modifier.padding(bottom = 12.dp),
                        textAlign = TextAlign.Center,
                    )
                    BButton(
                        label = "Volver a inicio de sesión",
                        onClick = { nav.pop() },
                        variant = ButtonVariant.Secondary,
                    )
                }
            } else {
                BText("¿Olvidaste tu contraseña?", BType.h1, BColors.textPrimary, Modifier.padding(bottom = 8.dp))
                BText(
                    text = "Escribe tu correo y te enviaremos un enlace para crear una contraseña nueva.",
                    style = BType.body,
                    color = BColors.textSecondary,
                    modifier = Modifier.padding(bottom = 24.dp),
                )
                BInput(
                    value = email,
                    onValueChange = { email = it },
                    label = "Correo electrónico",
                    placeholder = "tucorreo@ejemplo.com",
                    leftIcon = BIcons.Mail,
                    keyboardType = KeyboardType.Email,
                    capitalization = KeyboardCapitalization.None,
                )
                val message = formError
                if (message != null) {
                    BText(message, BType.caption, BColors.danger, Modifier.padding(bottom = 8.dp))
                }
                BButton(label = "Enviar enlace", onClick = { submit() }, loading = action.running)
            }
        }
    }
}
