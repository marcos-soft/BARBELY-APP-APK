package com.barbely.app.logic

import java.text.Normalizer

/**
 * Ilustración de respaldo para un servicio que todavía no tiene foto: se elige por palabras del
 * nombre ("Barba" → barba, "Degradado" → degradado, etc.).
 */
enum class ServiceArt { CORTE, FADE, BARBA, COMBO, AFEITADO, INFANTIL, CEJAS, COLOR, GENERICO }

private fun normalize(text: String): String =
    Normalizer.normalize(text, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase()

private fun artFromText(text: String, allowLoose: Boolean): ServiceArt? {
    val t = normalize(text)
    val hasBeard = t.contains("barba") || t.contains("bigote")
    val hasCut = t.contains("corte") || t.contains("cabello") || t.contains("pelo") || t.contains("peinado")
    return when {
        t.contains("combo") || t.contains("completo") || (hasBeard && hasCut) -> ServiceArt.COMBO
        t.contains("afeit") || t.contains("rasur") || t.contains("navaja") -> ServiceArt.AFEITADO
        t.contains("ceja") -> ServiceArt.CEJAS
        t.contains("nino") || t.contains("nina") || t.contains("infantil") || t.contains("kids") ||
            t.contains("peque") -> ServiceArt.INFANTIL
        t.contains("degrad") || t.contains("fade") || t.contains("taper") || t.contains("desvan") -> ServiceArt.FADE
        t.contains("tinte") || t.contains("color") || t.contains("mecha") || t.contains("decolor") ||
            t.contains("tintura") -> ServiceArt.COLOR
        hasBeard || t.contains("perfil") -> ServiceArt.BARBA
        hasCut || (allowLoose && t.contains("clasico")) -> ServiceArt.CORTE
        else -> null
    }
}

/** El nombre manda; si no dice nada, se intenta con la descripción. */
fun serviceArtFor(nombre: String, descripcion: String?): ServiceArt =
    artFromText(nombre, allowLoose = true)
        ?: descripcion?.let { artFromText(it, allowLoose = false) }
        ?: ServiceArt.GENERICO
