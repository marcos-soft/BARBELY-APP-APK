package com.barbely.app.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BInput
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.rememberActionRunner
import com.barbely.app.ui.components.tappable
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.nav.Route
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BType

@Composable
fun RegisterScreen() {
    val app = LocalApp.current
    val nav = LocalNav.current
    var nombre by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var formError by remember { mutableStateOf<String?>(null) }
    val action = rememberActionRunner()

    fun submit() {
        formError = null
        if (nombre.trim().isEmpty() || email.trim().isEmpty() || password.isEmpty()) {
            formError = "Completa todos los campos."
            return
        }
        if (password.length < 6) {
            formError = "La contraseña debe tener al menos 6 caracteres."
            return
        }
        if (password != confirmPassword) {
            formError = "Las contraseñas no coinciden."
            return
        }
        action.run(onError = { formError = it }) {
            // El registro público siempre crea un cliente. Los barberos y el gerente
            // se administran desde el panel del gerente.
            app.signUp(nombre.trim(), email.trim(), password)
            nav.resetTo(Route.Home)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Column(modifier = Modifier.padding(bottom = 24.dp)) {
            BText("Crea tu cuenta", BType.h1, BColors.textPrimary)
            BText(
                "Reserva tu primer corte en minutos", BType.body, BColors.textSecondary,
                Modifier.padding(top = 4.dp),
            )
        }

        BInput(
            value = nombre,
            onValueChange = { nombre = it },
            label = "Nombre completo",
            placeholder = "Tu nombre",
            leftIcon = BIcons.Person,
            capitalization = KeyboardCapitalization.Words,
        )
        BInput(
            value = email,
            onValueChange = { email = it },
            label = "Correo electrónico",
            placeholder = "tucorreo@ejemplo.com",
            leftIcon = BIcons.Mail,
            keyboardType = KeyboardType.Email,
            capitalization = KeyboardCapitalization.None,
        )
        BInput(
            value = password,
            onValueChange = { password = it },
            label = "Contraseña",
            placeholder = "Mínimo 6 caracteres",
            secure = true,
            leftIcon = BIcons.LockClosed,
            keyboardType = KeyboardType.Password,
            capitalization = KeyboardCapitalization.None,
        )
        BInput(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = "Confirmar contraseña",
            placeholder = "Repite tu contraseña",
            secure = true,
            leftIcon = BIcons.LockClosed,
            keyboardType = KeyboardType.Password,
            capitalization = KeyboardCapitalization.None,
        )
        val message = formError
        if (message != null) {
            BText(message, BType.caption, BColors.danger, Modifier.padding(bottom = 8.dp))
        }

        BButton(
            label = "Crear cuenta",
            onClick = { submit() },
            modifier = Modifier.padding(top = 12.dp),
            loading = action.running,
        )

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BText("¿Ya tienes cuenta? ", BType.body, BColors.textSecondary)
            BText(
                text = "Inicia sesión",
                style = BType.captionMedium,
                color = BColors.gold,
                modifier = Modifier.tappable { nav.push(Route.Login) },
            )
        }
    }
}
