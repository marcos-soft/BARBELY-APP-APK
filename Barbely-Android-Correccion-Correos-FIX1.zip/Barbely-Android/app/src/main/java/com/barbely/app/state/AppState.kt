package com.barbely.app.state

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.barbely.app.data.AppException
import com.barbely.app.data.Appointment
import com.barbely.app.data.AppointmentStatus
import com.barbely.app.data.Backend
import com.barbely.app.data.Barber
import com.barbely.app.data.BarberInput
import com.barbely.app.data.Bloqueo
import com.barbely.app.data.NewAppointment
import com.barbely.app.data.Schedule
import com.barbely.app.data.ScheduleDraft
import com.barbely.app.data.Service
import com.barbely.app.data.ServiceInput
import com.barbely.app.data.Stop
import com.barbely.app.data.TimeSlot
import com.barbely.app.data.User
import com.barbely.app.data.UserRole
import com.barbely.app.logic.BLOCK_MINUTES
import com.barbely.app.logic.BusyRange
import com.barbely.app.logic.getAvailableSlots
import com.barbely.app.logic.minutesToTime
import com.barbely.app.logic.nowMinutes
import com.barbely.app.logic.timeToMinutes
import com.barbely.app.logic.todayISO
import com.barbely.app.logic.weekdayOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val EMAIL_REGEX = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")

/**
 * Estado global de la app (equivale a AuthContext + los stores con listeners de Firestore de la
 * app original). Los datos llegan EN TIEMPO REAL desde Firebase: cada vez que alguien cambia algo
 * (otro cliente reserva, el gerente edita un servicio...) las listas se actualizan solas.
 *
 * Las operaciones que escriben en Firebase son `suspend`: se llaman desde una corrutina
 * (ver ActionRunner en la interfaz) y lanzan [AppException] con un mensaje listo para mostrar.
 */
class AppState(
    private val backend: Backend,
    private val scope: CoroutineScope,
) {

    /** Usuario con sesión iniciada (null si no hay sesión). */
    var user by mutableStateOf<User?>(null)
        private set

    /** True mientras se comprueba si había una sesión guardada al abrir la app. */
    var authLoading by mutableStateOf(true)
        private set

    var services by mutableStateOf<List<Service>>(emptyList())
        private set
    var barbers by mutableStateOf<List<Barber>>(emptyList())
        private set
    var schedules by mutableStateOf<List<Schedule>>(emptyList())
        private set

    /** Citas que el usuario actual puede ver (gerente: todas, barbero/cliente: las suyas). */
    var appointments by mutableStateOf<List<Appointment>>(emptyList())
        private set

    /** Horarios ocupados (de todos los clientes), solo para calcular la disponibilidad. */
    private var blocks by mutableStateOf<List<Bloqueo>>(emptyList())

    /** False hasta que Firebase entrega la primera lectura de todas las colecciones. */
    var dataReady by mutableStateOf(false)
        private set

    /** Mensaje de error de sincronización (por ejemplo, reglas de Firestore sin publicar). */
    var syncError by mutableStateOf<String?>(null)
        private set

    /** Sube cada vez que cambian los datos; sirve para recalcular la disponibilidad en pantalla. */
    var dataVersion by mutableIntStateOf(0)
        private set

    private val stops = mutableListOf<Stop>()
    private val pending = mutableSetOf<String>()

    /** Mientras es > 0, una operación (iniciar sesión, registrarse...) maneja la sesión por su cuenta. */
    private var authBusy = 0

    init {
        backend.listenAuth { uid -> onAuthChanged(uid) }
        // Salvavidas: si Firebase nunca respondiera, no dejar la pantalla de carga para siempre.
        scope.launch {
            delay(AUTH_TIMEOUT_MS)
            if (authLoading) authLoading = false
        }
    }

    // ------------------------------------------------------------------
    // Sesión y escuchas en tiempo real
    // ------------------------------------------------------------------

    /** Firebase avisa cuando hay (o deja de haber) una sesión guardada. */
    private fun onAuthChanged(uid: String?) {
        if (authBusy > 0) return
        if (uid == null) {
            if (user != null) endSession()
            authLoading = false
            return
        }
        if (user?.uid == uid) {
            authLoading = false
            return
        }
        restoreSession(uid)
    }

    private fun restoreSession(uid: String) {
        authBusy++
        scope.launch {
            try {
                val profile = backend.loadUser(uid)
                if (!profile.activo) {
                    backend.signOut()
                    syncError = "Esta cuenta está desactivada."
                } else {
                    startSession(profile)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Se conserva la sesión de Firebase: el usuario puede reintentar desde el aviso.
                syncError = e.message ?: "No se pudo cargar tu perfil."
            } finally {
                authBusy--
                authLoading = false
            }
        }
    }

    private fun startSession(profile: User) {
        user = profile
        syncError = null
        startListeners(profile)
    }

    private fun startListeners(profile: User) {
        stopListeners()
        pending.addAll(LISTENERS)
        dataReady = false
        stops += backend.listenServices({ services = it; ready("servicios") }, { failed("servicios", it) })
        stops += backend.listenBarbers({ barbers = it; ready("barberos") }, { failed("barberos", it) })
        stops += backend.listenSchedules({ schedules = it; ready("horarios") }, { failed("horarios", it) })
        stops += backend.listenAppointments(profile, { appointments = it; ready("citas") }, { failed("citas", it) })
        stops += backend.listenBlocks(todayISO(), { blocks = it; ready("bloqueos") }, { failed("bloqueos", it) })
    }

    private fun stopListeners() {
        for (stop in stops) {
            try {
                stop()
            } catch (e: Exception) {
                // Una escucha que ya terminó por error no se puede quitar dos veces: se ignora.
            }
        }
        stops.clear()
        pending.clear()
    }

    private fun ready(key: String) {
        pending.remove(key)
        if (pending.isEmpty()) dataReady = true
        dataVersion += 1
    }

    private fun failed(key: String, error: AppException) {
        syncError = error.message
        ready(key)
    }

    private fun endSession() {
        stopListeners()
        user = null
        services = emptyList()
        barbers = emptyList()
        schedules = emptyList()
        appointments = emptyList()
        blocks = emptyList()
        dataReady = false
        dataVersion += 1
    }

    /** Reintenta la conexión después de un error de sincronización. */
    fun retrySync() {
        syncError = null
        val current = user
        if (current != null) {
            startListeners(current)
        } else {
            val uid = backend.currentUid
            if (uid != null) {
                authLoading = true
                restoreSession(uid)
            }
        }
    }

    fun dismissSyncError() {
        syncError = null
    }

    private suspend fun <T> withAuthBusy(block: suspend () -> T): T {
        authBusy++
        try {
            return block()
        } finally {
            authBusy--
        }
    }

    // ------------------------------------------------------------------
    // Autenticación
    // ------------------------------------------------------------------

    suspend fun signIn(email: String, password: String): User {
        val cleaned = email.trim()
        if (!EMAIL_REGEX.matches(cleaned)) throw AppException("El correo electrónico no es válido.")
        if (password.isEmpty()) throw AppException("Escribe tu contraseña.")
        return withAuthBusy {
            val uid = backend.signIn(cleaned, password)
            val profile = try {
                backend.loadUser(uid)
            } catch (e: Exception) {
                backend.signOut()
                throw e
            }
            if (!profile.activo) {
                backend.signOut()
                throw AppException("Esta cuenta está desactivada.")
            }
            startSession(profile)
            profile
        }
    }

    /** El registro público siempre crea un cliente; barberos y gerente se administran aparte. */
    suspend fun signUp(nombre: String, email: String, password: String): User {
        val cleaned = email.trim()
        if (nombre.trim().isEmpty()) throw AppException("Escribe tu nombre.")
        if (!EMAIL_REGEX.matches(cleaned)) throw AppException("El correo electrónico no es válido.")
        if (password.length < 6) throw AppException("La contraseña debe tener al menos 6 caracteres.")
        return withAuthBusy {
            val uid = backend.signUp(nombre.trim(), cleaned, password)
            val profile = try {
                backend.createClientProfile(uid, nombre.trim(), cleaned)
            } catch (e: Exception) {
                // La cuenta de acceso ya existe: en el próximo inicio de sesión se creará el perfil.
                backend.signOut()
                throw e
            }
            startSession(profile)
            profile
        }
    }

    /** Envía por correo el enlace para crear una contraseña nueva. */
    suspend fun resetPassword(email: String) {
        val cleaned = email.trim()
        if (!EMAIL_REGEX.matches(cleaned)) throw AppException("El correo electrónico no es válido.")
        backend.sendPasswordReset(cleaned)
    }

    /** El barbero cambia su propio correo de acceso; nunca modifica credenciales de terceros. */
    suspend fun updateOwnBarberEmail(newEmail: String, currentPassword: String) {
        val current = user ?: throw AppException("No hay una sesión activa.")
        if (current.rol != UserRole.BARBERO) {
            throw AppException("Solo el barbero puede cambiar su propio correo de acceso.")
        }
        val cleaned = newEmail.trim()
        if (!EMAIL_REGEX.matches(cleaned)) throw AppException("El correo electrónico no es válido.")
        backend.updateOwnEmail(cleaned, currentPassword)
        user = current.copy(email = cleaned)
        barbers = barbers.map { barber ->
            if (barber.id == current.uid) barber.copy(email = cleaned) else barber
        }
    }

    suspend fun updateProfile(nombre: String, telefono: String?) {
        val current = user ?: throw AppException("No hay una sesión activa.")
        backend.updateUserProfile(current.uid, nombre, telefono)
        user = current.copy(nombre = nombre, telefono = telefono)
    }

    /**
     * Elimina la cuenta del cliente: pide la contraseña, cancela sus citas próximas (liberando
     * los horarios), borra su perfil y su cuenta de acceso.
     */
    suspend fun deleteAccount(password: String) {
        val current = user ?: return
        if (current.rol != UserRole.CLIENTE) {
            throw AppException("Las cuentas de barbero y de gerente las administra el gerente.")
        }
        if (password.isEmpty()) throw AppException("Escribe tu contraseña para confirmar.")
        withContext(NonCancellable) {
            backend.reauthenticate(password)
            cancelUpcomingAppointments(current)
            // Ya no hacen falta las escuchas: sin perfil, las reglas de Firestore las rechazarían.
            stopListeners()
            backend.deleteUserProfile(current.uid)
            backend.deleteAuthAccount()
        }
        endSession()
    }

    private suspend fun cancelUpcomingAppointments(client: User) {
        val today = todayISO()
        val upcoming = appointments.filter {
            it.clienteId == client.uid &&
                (it.estado == AppointmentStatus.PENDIENTE || it.estado == AppointmentStatus.CONFIRMADA) &&
                it.fecha >= today
        }
        for (cita in upcoming) {
            backend.setAppointmentStatus(cita.id, AppointmentStatus.CANCELADA, blocksOf(cita.id))
        }
    }

    fun signOut() {
        endSession()
        backend.signOut()
    }

    // ------------------------------------------------------------------
    // Consultas para las pantallas
    // ------------------------------------------------------------------

    fun activeServices(): List<Service> = services.filter { it.activo }

    fun activeBarbers(): List<Barber> = barbers.filter { it.activo }

    fun service(id: String?): Service? = services.firstOrNull { it.id == id }

    fun barber(id: String?): Barber? = barbers.firstOrNull { it.id == id }

    fun schedulesFor(barberoId: String): List<Schedule> = schedules.filter { it.barberoId == barberoId }

    /** Barbero que corresponde al usuario que inició sesión. */
    fun currentBarber(): Barber {
        val me = user
        val byId = barbers.firstOrNull { it.id == me?.uid }
        if (byId != null) return byId
        val byEmail = barbers.firstOrNull { me != null && it.email.equals(me.email, ignoreCase = true) }
        if (byEmail != null) return byEmail
        return Barber(
            id = me?.uid ?: "",
            nombre = me?.nombre ?: "Barbero",
            descripcion = null,
            especialidad = "",
            calificacionPromedio = null,
            activo = true,
            createdAt = "",
            email = me?.email,
        )
    }

    private fun resolve(a: Appointment): Appointment =
        a.copy(barbero = barber(a.barberoId), servicio = service(a.servicioId))

    private fun newestFirst(list: List<Appointment>): List<Appointment> =
        list.sortedByDescending { it.fecha + it.horaInicio }

    fun appointment(id: String?): Appointment? =
        appointments.firstOrNull { it.id == id }?.let { resolve(it) }

    fun clientAppointments(clienteId: String): List<Appointment> =
        newestFirst(appointments.filter { it.clienteId == clienteId }).map { resolve(it) }

    /** La cita activa más cercana en el tiempo (pendiente o confirmada) que todavía no termina. */
    fun nextClientAppointment(clienteId: String): Appointment? {
        val today = todayISO()
        val now = nowMinutes()
        return appointments
            .filter {
                it.clienteId == clienteId &&
                    (it.estado == AppointmentStatus.PENDIENTE || it.estado == AppointmentStatus.CONFIRMADA) &&
                    (it.fecha > today || (it.fecha == today && timeToMinutes(it.horaFin) > now))
            }
            .minByOrNull { it.fecha + it.horaInicio }
            ?.let { resolve(it) }
    }

    fun barberAppointments(barberoId: String): List<Appointment> =
        newestFirst(appointments.filter { it.barberoId == barberoId }).map { resolve(it) }

    /** Citas de un barbero en un día puntual (sin canceladas), ordenadas por hora — para la Agenda. */
    fun barberAppointmentsByDate(barberoId: String, fecha: String): List<Appointment> =
        appointments
            .filter {
                it.barberoId == barberoId && it.fecha == fecha && it.estado != AppointmentStatus.CANCELADA
            }
            .sortedBy { it.horaInicio }
            .map { resolve(it) }

    fun allAppointments(): List<Appointment> = newestFirst(appointments).map { resolve(it) }

    private fun blocksOf(citaId: String): List<Bloqueo> = blocks.filter { it.citaId == citaId }

    /**
     * Rangos ocupados de un barbero en una fecha: las citas que el usuario puede ver (sin las
     * canceladas) más los bloqueos de todos los clientes (es lo único que un cliente sabe de las citas ajenas).
     */
    private fun busyRanges(barberoId: String, fecha: String): List<BusyRange> {
        val fromAppointments = appointments
            .filter { it.barberoId == barberoId && it.fecha == fecha && it.estado != AppointmentStatus.CANCELADA }
            .map { BusyRange(timeToMinutes(it.horaInicio), timeToMinutes(it.horaFin)) }
        val fromBlocks = blocks
            .filter { it.barberoId == barberoId && it.fecha == fecha }
            .map {
                val start = timeToMinutes(it.hora)
                BusyRange(start, start + BLOCK_MINUTES)
            }
        return fromAppointments + fromBlocks
    }

    /**
     * Franjas del barbero para un día. Considera las citas de todos los clientes
     * y, si la fecha es hoy, deshabilita las horas que ya pasaron.
     */
    fun slotsFor(barberId: String?, fecha: String?, duracionMinutos: Int): List<TimeSlot> {
        if (barberId == null || fecha == null || duracionMinutos <= 0) return emptyList()
        val earliest = if (fecha == todayISO()) nowMinutes() + 1 else 0
        return getAvailableSlots(
            weekday = weekdayOf(fecha),
            schedules = schedulesFor(barberId),
            busy = busyRanges(barberId, fecha),
            duracionMinutos = duracionMinutos,
            earliestStart = earliest,
        )
    }

    // ------------------------------------------------------------------
    // Citas
    // ------------------------------------------------------------------

    suspend fun createAppointment(barberoId: String, servicioId: String, fecha: String, horaInicio: String): Appointment {
        val current = user ?: throw AppException("Debes iniciar sesión para reservar.")
        if (current.rol != UserRole.CLIENTE) throw AppException("Solo los clientes pueden reservar citas.")
        val chosen = service(servicioId) ?: throw AppException("El servicio ya no está disponible.")
        // Comprobación rápida con lo que ya se sabe; la definitiva la hace Firebase al guardar.
        val stillFree = slotsFor(barberoId, fecha, chosen.duracion).any { it.horaInicio == horaInicio && it.disponible }
        if (!stillFree) throw AppException("Ese horario ya no está disponible. Elige otro.")
        val horaFin = minutesToTime(timeToMinutes(horaInicio) + chosen.duracion)
        return backend.createAppointment(
            NewAppointment(
                cliente = current,
                barberoId = barberoId,
                servicioId = servicioId,
                fecha = fecha,
                horaInicio = horaInicio,
                horaFin = horaFin,
                duracionMinutos = chosen.duracion,
                precio = chosen.precio,
            ),
        )
    }

    /**
     * Mismas reglas que las de Firestore: el gerente puede todo, el barbero cambia el estado de
     * sus citas y el cliente solo puede cancelar las suyas. Al cancelar se liberan los horarios.
     */
    suspend fun updateAppointmentStatus(id: String, estado: AppointmentStatus) {
        val current = user ?: throw AppException("No hay una sesión activa.")
        val cita = appointments.firstOrNull { it.id == id } ?: throw AppException("Cita no encontrada.")
        val allowed = when (current.rol) {
            UserRole.GERENTE -> true
            UserRole.BARBERO -> cita.barberoId == current.uid
            UserRole.CLIENTE -> cita.clienteId == current.uid && estado == AppointmentStatus.CANCELADA
        }
        if (!allowed) throw AppException("No tienes permiso para modificar esta cita.")
        val release = if (estado == AppointmentStatus.CANCELADA) blocksOf(id) else emptyList()
        backend.setAppointmentStatus(id, estado, release)
    }

    // ------------------------------------------------------------------
    // Administración (gerente)
    // ------------------------------------------------------------------

    private fun requireManager() {
        if (user?.rol != UserRole.GERENTE) throw AppException("Solo el gerente puede hacer esto.")
    }

    suspend fun saveService(
        id: String?,
        nombre: String,
        descripcion: String?,
        precio: Double,
        duracion: Int,
        imagen: String?,
        activo: Boolean,
    ) {
        requireManager()
        backend.saveService(id, ServiceInput(nombre, descripcion, precio, duracion, imagen, activo))
    }

    suspend fun setServiceActive(id: String, activo: Boolean) {
        requireManager()
        backend.setServiceActive(id, activo)
    }

    /**
     * Crea (id == null) o edita un barbero. Al crear también se crea su cuenta de acceso en
     * Firebase Authentication (rol "barbero") con la contraseña inicial.
     */
    suspend fun saveBarber(
        id: String?,
        nombre: String,
        especialidad: String,
        descripcion: String?,
        activo: Boolean,
        email: String,
        initialPassword: String?,
    ) {
        requireManager()
        val cleanEmail = email.trim()
        val input = BarberInput(nombre, especialidad, descripcion, activo, cleanEmail.ifEmpty { null })
        if (id == null) {
            if (cleanEmail.isEmpty() || initialPassword == null || initialPassword.length < 6) {
                throw AppException("Para crear un barbero necesitas correo y contraseña inicial.")
            }
            if (!EMAIL_REGEX.matches(cleanEmail)) throw AppException("El correo electrónico no es válido.")
            // Aunque el usuario salga de la pantalla, los dos pasos (cuenta + perfil) deben terminar.
            withContext(NonCancellable) {
                val uid = backend.createStaffAccount(cleanEmail, initialPassword)
                try {
                    backend.createBarber(uid, input)
                } catch (e: AppException) {
                    throw AppException(
                        "La cuenta de acceso del barbero se creó, pero no se pudo guardar su perfil: " +
                            "${e.message} Vuelve a intentarlo con el mismo correo y la misma contraseña.",
                    )
                }
            }
        } else {
            if (cleanEmail.isNotEmpty() && !EMAIL_REGEX.matches(cleanEmail)) {
                throw AppException("El correo electrónico no es válido.")
            }
            backend.updateBarber(id, input)
        }
    }

    /** Un barbero inactivo no aparece al reservar y tampoco puede iniciar sesión. */
    suspend fun setBarberActive(id: String, activo: Boolean) {
        requireManager()
        backend.setBarberActive(id, activo)
    }

    // ------------------------------------------------------------------
    // Barbero
    // ------------------------------------------------------------------

    suspend fun updateBarberProfile(id: String, especialidad: String, descripcion: String?) {
        val current = user ?: throw AppException("No hay una sesión activa.")
        if (current.rol != UserRole.GERENTE && current.uid != id) {
            throw AppException("No tienes permiso para editar este perfil.")
        }
        backend.updateBarberProfile(id, especialidad, descripcion)
    }

    /** Deja los horarios del barbero como están en [drafts] y devuelve el resultado final. */
    suspend fun saveSchedules(barberoId: String, drafts: List<ScheduleDraft>): List<Schedule> {
        val current = user ?: throw AppException("No hay una sesión activa.")
        if (current.rol != UserRole.GERENTE && current.uid != barberoId) {
            throw AppException("No tienes permiso para editar este horario.")
        }
        return backend.saveSchedules(barberoId, schedulesFor(barberoId), drafts)
    }

    private companion object {
        const val AUTH_TIMEOUT_MS = 12_000L
        val LISTENERS = listOf("servicios", "barberos", "horarios", "citas", "bloqueos")
    }
}
