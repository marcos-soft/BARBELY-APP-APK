package com.barbely.app.logic

import java.time.LocalDate
import java.time.LocalTime
import java.util.Locale

/**
 * BARBELY — Utilidades de tiempo (equivalente a src/utils/time.ts).
 * Trabaja en "minutos desde medianoche" para comparar horarios ("09:30")
 * sin pasar por objetos de fecha (evita problemas de huso horario).
 */

fun timeToMinutes(time: String): Int {
    val parts = time.split(":")
    val hours = parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 0
    val minutes = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
    return hours * 60 + minutes
}

fun minutesToTime(totalMinutes: Int): String {
    val hours = (totalMinutes / 60) % 24
    val minutes = totalMinutes % 60
    return String.format(Locale.US, "%02d:%02d", hours, minutes)
}

/** "YYYY-MM-DD" en hora local. */
fun toISODate(date: LocalDate): String = date.toString()

fun todayISO(): String = toISODate(LocalDate.now())

/** Minuto actual del día (0..1439). */
fun nowMinutes(): Int {
    val now = LocalTime.now()
    return now.hour * 60 + now.minute
}

fun parseFecha(fecha: String): LocalDate? =
    try {
        LocalDate.parse(fecha)
    } catch (e: Exception) {
        null
    }

/** Día de la semana de una fecha "YYYY-MM-DD": 0 = domingo ... 6 = sábado. */
fun weekdayOf(fecha: String): Int {
    val date = parseFecha(fecha) ?: LocalDate.now()
    return date.dayOfWeek.value % 7 // DayOfWeek: lunes = 1 ... domingo = 7
}

val WEEKDAY_SHORT = listOf("dom", "lun", "mar", "mié", "jue", "vie", "sáb")
val WEEKDAY_LONG = listOf("domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado")
val MONTH_SHORT = listOf("ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic")
val MONTH_LONG = listOf(
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
)

/** "mié, 21 oct" */
fun formatFechaCorta(fecha: String): String {
    val date = parseFecha(fecha) ?: return fecha
    val wd = WEEKDAY_SHORT[date.dayOfWeek.value % 7]
    return "$wd, ${date.dayOfMonth} ${MONTH_SHORT[date.monthValue - 1]}"
}

/** "miércoles, 21 de octubre" */
fun formatFechaLarga(fecha: String): String {
    val date = parseFecha(fecha) ?: return fecha
    val wd = WEEKDAY_LONG[date.dayOfWeek.value % 7]
    return "$wd, ${date.dayOfMonth} de ${MONTH_LONG[date.monthValue - 1]}"
}

/** "$8.00" */
fun money(value: Double): String = "$" + String.format(Locale.US, "%.2f", value)

/** "$12" (sin decimales) */
fun moneyRounded(value: Double): String = "$" + String.format(Locale.US, "%.0f", value)

fun decimal1(value: Double): String = String.format(Locale.US, "%.1f", value)
