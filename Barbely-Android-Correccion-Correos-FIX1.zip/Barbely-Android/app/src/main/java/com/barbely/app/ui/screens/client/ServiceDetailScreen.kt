package com.barbely.app.ui.screens.client

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.barbely.app.logic.money
import com.barbely.app.logic.serviceArtFor
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BHeader
import com.barbely.app.ui.components.BIcon
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.ErrorState
import com.barbely.app.ui.components.LoadingState
import com.barbely.app.ui.components.ReferencePill
import com.barbely.app.ui.components.ScreenFooter
import com.barbely.app.ui.components.ServiceImage
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.nav.Route
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType

@Composable
fun ServiceDetailScreen(serviceId: String) {
    val app = LocalApp.current
    val nav = LocalNav.current
    val service = app.service(serviceId)

    if (service == null) {
        Column(modifier = Modifier.fillMaxSize().background(BColors.background)) {
            BHeader(title = "Servicio")
            if (!app.dataReady) {
                LoadingState("Cargando servicio…")
            } else {
                ErrorState(title = "Servicio no encontrado", description = "Puede que ya no esté disponible.")
            }
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BColors.background)
            .navigationBarsPadding(),
    ) {
        BHeader(title = service.nombre)
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            val photoShape = RoundedCornerShape(BRadius.lg)
            ServiceImage(
                source = service.imagen,
                art = serviceArtFor(service.nombre, service.descripcion),
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4f / 3f)
                    .clip(photoShape)
                    .border(1.dp, BColors.borderSubtle, photoShape),
                maxSide = 800,
                description = "Foto de referencia de ${service.nombre}",
                overlay = { isPhoto -> ReferencePill(isPhoto) },
            )
            BText(service.nombre, BType.h1, BColors.textPrimary)
            val description = service.descripcion
            if (!description.isNullOrEmpty()) {
                BText(description, BType.body, BColors.textSecondary)
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                MetaBlock(Modifier.weight(1f), BIcons.Time, "Duración", "${service.duracion} min")
                MetaBlock(Modifier.weight(1f), BIcons.Pricetag, "Precio", money(service.precio))
            }
        }
        ScreenFooter {
            BButton(
                label = "Reservar este servicio",
                onClick = { nav.push(Route.BookingBarber(service.id)) },
            )
        }
    }
}

@Composable
private fun MetaBlock(modifier: Modifier, icon: Int, label: String, value: String) {
    val shape = RoundedCornerShape(BRadius.lg)
    Column(
        modifier = modifier
            .background(BColors.surface, shape)
            .border(1.dp, BColors.borderSubtle, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        BIcon(icon, 18.dp, BColors.textSecondary)
        BText(label, BType.caption, BColors.textMuted, Modifier.padding(top = 4.dp))
        BText(value, BType.h3, BColors.textPrimary)
    }
}
