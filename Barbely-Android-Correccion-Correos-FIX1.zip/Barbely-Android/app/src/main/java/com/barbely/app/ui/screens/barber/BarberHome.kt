package com.barbely.app.ui.screens.barber

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import com.barbely.app.data.AppointmentStatus
import com.barbely.app.logic.decimal1
import com.barbely.app.logic.moneyRounded
import com.barbely.app.logic.todayISO
import com.barbely.app.ui.components.AppointmentCard
import com.barbely.app.ui.components.Avatar
import com.barbely.app.ui.components.BButton
import com.barbely.app.ui.components.BIcon
import com.barbely.app.ui.components.BInput
import com.barbely.app.ui.components.BText
import com.barbely.app.ui.components.BottomTabBar
import com.barbely.app.ui.components.ButtonVariant
import com.barbely.app.ui.components.DateSelector
import com.barbely.app.ui.components.EmptyState
import com.barbely.app.ui.components.FilterChip
import com.barbely.app.ui.components.LoadingState
import com.barbely.app.ui.components.StatCard
import com.barbely.app.ui.components.TabItem
import com.barbely.app.ui.components.TabTitle
import com.barbely.app.ui.components.rememberActionRunner
import com.barbely.app.ui.components.tappable
import com.barbely.app.ui.nav.LocalApp
import com.barbely.app.ui.nav.LocalNav
import com.barbely.app.ui.nav.Route
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BIcons
import com.barbely.app.ui.theme.BType
import kotlinx.coroutines.delay

/** Pantalla principal del barbero: Dashboard, Agenda, Citas y Perfil. */
@Composable
fun BarberHome() {
    val nav = LocalNav.current
    val tabs = remember {
        listOf(
            TabItem("Dashboard", BIcons.Grid),
            TabItem("Agenda", BIcons.Calendar),
            TabItem("Citas", BIcons.ListIcon),
            TabItem("Perfil", BIcons.Person),
        )
    }
    Column(modifier = Modifier.fillMaxSize().background(BColors.background).imePadding()) {
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (nav.homeTab) {
                0 -> BarberDashboardTab()
                1 -> BarberAgendaTab()
                2 -> BarberAppointmentsTab()
                else -> BarberProfileTab()
            }
        }
        BottomTabBar(items = tabs, selected = nav.homeTab, onSelect = { nav.homeTab = it })
    }
}

@Composable
private fun BarberDashboardTab() {
    val app = LocalApp.current
    val nav = LocalNav.current
    val barber = app.currentBarber()
    val today = todayISO()
    val todayAppointments = app.barberAppointmentsByDate(barber.id, today)
    val pendientes = todayAppointments.count { it.estado == AppointmentStatus.PENDIENTE }
    val ingresoEstimado = todayAppointments
        .filter { it.estado != AppointmentStatus.CANCELADA }
        .sumOf { it.precio }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, top = 32.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            BText("Hola, ${barber.nombre.trim().split(" ").first()}", BType.h1, BColors.textPrimary)
            BText("Este es tu resumen de hoy", BType.body, BColors.textSecondary)
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Citas hoy", todayAppointments.size.toString(), Modifier.weight(1f))
            StatCard("Por confirmar", pendientes.toString(), Modifier.weight(1f))
            StatCard("Ingreso estimado", moneyRounded(ingresoEstimado), Modifier.weight(1f))
        }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                BText("Hoy", BType.h3, BColors.textPrimary)
                BText(
                    text = "Ver agenda",
                    style = BType.captionMedium,
                    color = BColors.gold,
                    modifier = Modifier.tappable { nav.homeTab = 1 },
                )
            }
            if (!app.dataReady) {
                LoadingState("Cargando tus citas…")
            } else if (todayAppointments.isEmpty()) {
                EmptyState(
                    icon = BIcons.Calendar,
                    title = "Sin citas hoy",
                    description = "Disfruta el día libre.",
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    for (appointment in todayAppointments.take(3)) {
                        AppointmentCard(
                            appointment = appointment,
                            subtitle = appointment.clienteNombre,
                            onClick = { nav.push(Route.BarberAppointment(appointment.id)) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BarberAgendaTab() {
    val app = LocalApp.current
    val nav = LocalNav.current
    val barber = app.currentBarber()
    var selectedDate by remember { mutableStateOf(todayISO()) }
    val appointments = app.barberAppointmentsByDate(barber.id, selectedDate)

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        TabTitle("Agenda", bottomPadding = 12.dp)
        Box(modifier = Modifier.padding(start = 24.dp, end = 24.dp, bottom = 16.dp)) {
            DateSelector(selectedDate = selectedDate, onSelect = { selectedDate = it })
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (!app.dataReady) {
                item { LoadingState("Cargando tu agenda…") }
            } else if (appointments.isEmpty()) {
                item { EmptyState(icon = BIcons.Calendar, title = "Sin citas este día") }
            } else {
                items(appointments, key = { it.id }) { appointment ->
                    AppointmentCard(
                        appointment = appointment,
                        subtitle = appointment.clienteNombre,
                        onClick = { nav.push(Route.BarberAppointment(appointment.id)) },
                    )
                }
            }
        }
    }
}

private data class StatusFilter(val status: AppointmentStatus?, val label: String)

private val BARBER_FILTERS = listOf(
    StatusFilter(null, "Todas"),
    StatusFilter(AppointmentStatus.PENDIENTE, "Pendientes"),
    StatusFilter(AppointmentStatus.CONFIRMADA, "Confirmadas"),
    StatusFilter(AppointmentStatus.COMPLETADA, "Completadas"),
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BarberAppointmentsTab() {
    val app = LocalApp.current
    val nav = LocalNav.current
    val barber = app.currentBarber()
    var filter by remember { mutableStateOf<AppointmentStatus?>(null) }
    val all = app.barberAppointments(barber.id)
    val filtered = if (filter == null) all else all.filter { it.estado == filter }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        TabTitle("Citas", bottomPadding = 12.dp)
        FlowRow(
            modifier = Modifier.padding(start = 24.dp, end = 24.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (option in BARBER_FILTERS) {
                FilterChip(
                    label = option.label,
                    active = filter == option.status,
                    onClick = { filter = option.status },
                )
            }
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (!app.dataReady) {
                item { LoadingState("Cargando tus citas…") }
            } else if (filtered.isEmpty()) {
                item { EmptyState(icon = BIcons.ListIcon, title = "No hay citas en este filtro") }
            } else {
                items(filtered, key = { it.id }) { appointment ->
                    AppointmentCard(
                        appointment = appointment,
                        subtitle = appointment.clienteNombre,
                        onClick = { nav.push(Route.BarberAppointment(appointment.id)) },
                    )
                }
            }
        }
    }
}

@Composable
private fun BarberProfileTab() {
    val app = LocalApp.current
    val nav = LocalNav.current
    val barber = app.currentBarber()
    // Se vuelven a leer cuando Firebase termina de cargar (antes solo hay un perfil vacío provisional).
    var especialidad by remember(barber.id, app.dataReady) { mutableStateOf(barber.especialidad) }
    var descripcion by remember(barber.id, app.dataReady) { mutableStateOf(barber.descripcion ?: "") }
    var loginEmail by remember(barber.id, app.dataReady) { mutableStateOf(barber.email ?: app.user?.email.orEmpty()) }
    var currentPassword by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    var specialtyError by remember { mutableStateOf<String?>(null) }
    var saveError by remember { mutableStateOf<String?>(null) }
    var emailSaved by remember { mutableStateOf(false) }
    var emailError by remember { mutableStateOf<String?>(null) }
    val saveAction = rememberActionRunner()
    val emailAction = rememberActionRunner()
    val rating = barber.calificacionPromedio

    LaunchedEffect(saved) {
        if (saved) {
            delay(1800)
            saved = false
        }
    }

    LaunchedEffect(emailSaved) {
        if (emailSaved) {
            delay(2500)
            emailSaved = false
        }
    }

    fun save() {
        if (especialidad.trim().isEmpty()) {
            specialtyError = "La especialidad no puede estar vacía."
            return
        }
        specialtyError = null
        saveError = null
        saveAction.run(onError = { saveError = it }) {
            app.updateBarberProfile(barber.id, especialidad.trim(), descripcion.trim().ifEmpty { null })
            saved = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = 56.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Avatar(name = barber.nombre, size = 72)
            BText(barber.nombre, BType.h2, BColors.textPrimary, Modifier.padding(top = 12.dp))
            if (rating != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    BIcon(BIcons.Star, 14.dp, BColors.gold)
                    BText("${decimal1(rating)} de calificación", BType.caption, BColors.textSecondary)
                }
            }
        }

        Column {
            BInput(
                value = especialidad,
                onValueChange = { especialidad = it },
                label = "Especialidad",
                leftIcon = BIcons.Cut,
                error = specialtyError,
            )
            BInput(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = "Descripción",
                placeholder = "Cuéntale al cliente sobre tu estilo",
                leftIcon = BIcons.DocumentText,
                multiline = true,
            )
            BText("Correo de acceso", BType.h3, BColors.textPrimary, Modifier.padding(top = 20.dp, bottom = 8.dp))
            BText(
                "Iniciaste sesión con el correo anterior. Escribe aquí el correo nuevo que te asignó el gerente y confirma con tu contraseña actual.",
                BType.caption,
                BColors.textMuted,
                Modifier.padding(bottom = 12.dp),
            )
            BInput(
                value = loginEmail,
                onValueChange = { loginEmail = it },
                label = "Nuevo correo electrónico",
                leftIcon = BIcons.Mail,
                keyboardType = KeyboardType.Email,
                capitalization = KeyboardCapitalization.None,
            )
            BInput(
                value = currentPassword,
                onValueChange = { currentPassword = it },
                label = "Contraseña actual",
                leftIcon = BIcons.LockClosed,
                secure = true,
                keyboardType = KeyboardType.Password,
                capitalization = KeyboardCapitalization.None,
            )
            if (emailError != null) {
                BText(emailError!!, BType.caption, BColors.danger, Modifier.padding(bottom = 8.dp))
            }
            BButton(
                label = if (emailSaved) "Correo actualizado ✓" else "Actualizar correo de acceso",
                onClick = {
                    emailError = null
                    emailAction.run(onError = { emailError = it }) {
                        app.updateOwnBarberEmail(loginEmail, currentPassword)
                        currentPassword = ""
                        emailSaved = true
                    }
                },
                variant = ButtonVariant.Secondary,
                loading = emailAction.running,
                enabled = app.dataReady && loginEmail.isNotBlank() && currentPassword.isNotBlank(),
            )
            BText(
                "Después del cambio, cierra sesión y vuelve a entrar con el correo nuevo y la misma contraseña.",
                BType.caption,
                BColors.textMuted,
                Modifier.padding(top = 8.dp, bottom = 16.dp),
            )
            val problem = saveError
            if (problem != null) {
                BText(problem, BType.caption, BColors.danger, Modifier.padding(bottom = 8.dp))
            }
            BButton(
                label = if (saved) "Guardado ✓" else "Guardar cambios",
                onClick = { save() },
                variant = ButtonVariant.Secondary,
                loading = saveAction.running,
                enabled = app.dataReady,
            )
        }

        BButton(
            label = "Mi disponibilidad",
            onClick = { nav.push(Route.BarberAvailability) },
            variant = ButtonVariant.Ghost,
            icon = BIcons.Time,
        )
        BButton(
            label = "Cerrar sesión",
            onClick = {
                app.signOut()
                nav.resetTo(Route.Welcome)
            },
            modifier = Modifier.padding(top = 4.dp),
            variant = ButtonVariant.Ghost,
        )
    }
}
