package com.barbely.app.data

import com.google.firebase.FirebaseOptions

/**
 * Configuración del proyecto de Firebase "Barbely" (barbely-56710): es la MISMA que usaba la app
 * original de Expo (archivo .env), así que la app se conecta a la misma base de datos y a los
 * mismos usuarios.
 *
 * Estos valores NO son secretos: identifican el proyecto. La seguridad de los datos la dan las
 * reglas de Firestore (carpeta firebase/ del proyecto).
 *
 * Si algún día cambias de proyecto de Firebase: registra una app de Android con el paquete
 * com.barbely.app, descarga google-services.json y ponlo en la carpeta app/ (entonces esta
 * configuración deja de usarse). Mira el archivo LEEME.md.
 */
object FirebaseConfig {
    const val PROJECT_ID = "barbely-56710"
    const val API_KEY = "AIzaSyB80X1_JnjQCpgOaZG-NH3ROdrRTaq6FOI"
    const val APP_ID = "1:107819799409:web:19611743d504d86a129cd0"
    const val STORAGE_BUCKET = "barbely-56710.firebasestorage.app"
    const val SENDER_ID = "107819799409"

    fun options(): FirebaseOptions =
        FirebaseOptions.Builder()
            .setApiKey(API_KEY)
            .setApplicationId(APP_ID)
            .setProjectId(PROJECT_ID)
            .setStorageBucket(STORAGE_BUCKET)
            .setGcmSenderId(SENDER_ID)
            .build()
}
