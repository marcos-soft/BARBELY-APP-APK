package com.barbely.app.ui.components

import android.graphics.BitmapFactory
import android.util.Base64
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.barbely.app.R
import com.barbely.app.data.Http
import com.barbely.app.logic.ServiceArt
import com.barbely.app.logic.computeSampleSize
import com.barbely.app.logic.dataUriPayload
import com.barbely.app.logic.isRemoteImage
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType
import java.util.Collections
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Ilustración incluida en la app para un servicio que todavía no tiene foto. */
fun serviceArtRes(art: ServiceArt): Int = when (art) {
    ServiceArt.CORTE -> R.drawable.svc_corte
    ServiceArt.FADE -> R.drawable.svc_fade
    ServiceArt.BARBA -> R.drawable.svc_barba
    ServiceArt.COMBO -> R.drawable.svc_combo
    ServiceArt.AFEITADO -> R.drawable.svc_afeitado
    ServiceArt.INFANTIL -> R.drawable.svc_infantil
    ServiceArt.CEJAS -> R.drawable.svc_cejas
    ServiceArt.COLOR -> R.drawable.svc_color
    ServiceArt.GENERICO -> R.drawable.svc_generico
}

@Immutable
private class LoadedImage(val bitmap: ImageBitmap?, val done: Boolean)

/** Memoria de fotos ya decodificadas (para no repetir el trabajo al desplazar las listas). */
private object ServiceImageCache {
    private const val CACHE_BYTES = 24 * 1024 * 1024
    private const val REMOTE_MAX_BYTES = 6 * 1024 * 1024

    private val memory = object : LruCache<String, ImageBitmap>(CACHE_BYTES) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }
    private val failed: MutableSet<String> = Collections.synchronizedSet(HashSet())

    private fun keyOf(source: String, maxSide: Int): String = "$maxSide:${source.length}:${source.hashCode()}"

    fun peek(source: String, maxSide: Int): ImageBitmap? = memory.get(keyOf(source, maxSide))

    suspend fun load(source: String, maxSide: Int): ImageBitmap? {
        val key = keyOf(source, maxSide)
        val cached = memory.get(key)
        if (cached != null) return cached
        if (failed.contains(key)) return null
        val bitmap = withContext(Dispatchers.IO) { decode(source, maxSide) }
        if (bitmap == null) {
            failed.add(key)
            return null
        }
        memory.put(key, bitmap)
        return bitmap
    }

    /** Foto incrustada ("data:image/...;base64,...") o descargada de un enlace https. */
    private fun decode(source: String, maxSide: Int): ImageBitmap? {
        try {
            val payload = dataUriPayload(source)
            val bytes: ByteArray = if (payload != null) {
                Base64.decode(payload, Base64.DEFAULT)
            } else if (isRemoteImage(source)) {
                Http.download(source, REMOTE_MAX_BYTES)
            } else {
                return null
            }
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            val options = BitmapFactory.Options()
            options.inSampleSize = computeSampleSize(bounds.outWidth, bounds.outHeight, maxSide)
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) ?: return null
            return bitmap.asImageBitmap()
        } catch (e: Exception) {
            return null
        } catch (e: OutOfMemoryError) {
            return null
        }
    }
}

@Composable
private fun rememberLoadedImage(source: String?, maxSide: Int): LoadedImage {
    val state = produceState(
        initialValue = initialImage(source, maxSide),
        key1 = source,
        key2 = maxSide,
    ) {
        value = if (source.isNullOrBlank()) {
            LoadedImage(null, true)
        } else {
            LoadedImage(ServiceImageCache.load(source, maxSide), true)
        }
    }
    return state.value
}

private fun initialImage(source: String?, maxSide: Int): LoadedImage {
    if (source.isNullOrBlank()) return LoadedImage(null, true)
    val cached = ServiceImageCache.peek(source, maxSide)
    return if (cached != null) LoadedImage(cached, true) else LoadedImage(null, false)
}

/**
 * Foto de referencia de un servicio. Si [source] está vacía o no se puede cargar se muestra la
 * ilustración [art]. [overlay] recibe `true` cuando lo que se ve es la foto real del servicio.
 *
 * El tamaño y el recorte (clip) los pone quien lo llama en [modifier].
 */
@Composable
fun ServiceImage(
    source: String?,
    art: ServiceArt,
    modifier: Modifier = Modifier,
    maxSide: Int = 800,
    contentScale: ContentScale = ContentScale.Crop,
    description: String? = null,
    overlay: @Composable BoxScope.(isPhoto: Boolean) -> Unit = {},
) {
    val loaded = rememberLoadedImage(source, maxSide)
    val bitmap = loaded.bitmap
    Box(modifier = modifier.background(BColors.surfaceElevated)) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = description,
                modifier = Modifier.fillMaxSize(),
                contentScale = contentScale,
            )
        } else if (loaded.done) {
            Image(
                painter = painterResource(id = serviceArtRes(art)),
                contentDescription = description,
                modifier = Modifier.fillMaxSize(),
                contentScale = contentScale,
            )
        }
        overlay(bitmap != null)
    }
}

/** Etiqueta sobre la imagen grande: deja claro si es una foto real o una ilustración. */
@Composable
fun BoxScope.ReferencePill(isPhoto: Boolean) {
    BText(
        text = if (isPhoto) "Foto de referencia" else "Imagen ilustrativa",
        style = BType.captionMedium,
        color = BColors.textPrimary,
        modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(12.dp)
            .background(BColors.overlay, RoundedCornerShape(BRadius.pill))
            .padding(horizontal = 12.dp, vertical = 5.dp),
    )
}
