package com.barbely.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.barbely.app.data.TimeSlot
import com.barbely.app.logic.MONTH_SHORT
import com.barbely.app.logic.WEEKDAY_SHORT
import com.barbely.app.logic.toISODate
import com.barbely.app.ui.theme.BColors
import com.barbely.app.ui.theme.BRadius
import com.barbely.app.ui.theme.BType
import java.time.LocalDate

/** Selector horizontal de fechas: hoy y los próximos días (ui/DateSelector.tsx). */
@Composable
fun DateSelector(selectedDate: String, onSelect: (String) -> Unit, daysAhead: Int = 14) {
    val days = remember(daysAhead) {
        val today = LocalDate.now()
        List(daysAhead) { offset -> today.plusDays(offset.toLong()) }
    }
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        for (date in days) {
            val iso = toISODate(date)
            val isSelected = iso == selectedDate
            val shape = RoundedCornerShape(BRadius.md)
            val textColor = if (isSelected) BColors.onGold else BColors.textMuted
            Column(
                modifier = Modifier
                    .width(56.dp)
                    .background(if (isSelected) BColors.gold else BColors.surface, shape)
                    .border(1.dp, if (isSelected) BColors.gold else BColors.borderSubtle, shape)
                    .tappable { onSelect(iso) }
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                BText(WEEKDAY_SHORT[date.dayOfWeek.value % 7], BType.caption, textColor)
                BText(
                    text = date.dayOfMonth.toString(),
                    style = BType.h3,
                    color = if (isSelected) BColors.onGold else BColors.textPrimary,
                )
                BText(MONTH_SHORT[date.monthValue - 1], BType.caption, textColor)
            }
        }
    }
}

/** Cuadrícula de horas; las ocupadas aparecen tachadas y no se pueden elegir (ui/TimeSelector.tsx). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TimeSelector(slots: List<TimeSlot>, selectedTime: String?, onSelect: (String) -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (slot in slots) {
            val isSelected = slot.horaInicio == selectedTime
            val disabled = !slot.disponible
            val shape = RoundedCornerShape(BRadius.sm)
            val background = when {
                isSelected -> BColors.gold
                disabled -> BColors.backgroundElevated
                else -> BColors.surface
            }
            val borderColor = if (isSelected) BColors.gold else BColors.borderSubtle
            val textColor = when {
                isSelected -> BColors.onGold
                disabled -> BColors.textMuted
                else -> BColors.textPrimary
            }
            BText(
                text = slot.horaInicio,
                style = BType.bodyMedium,
                color = textColor,
                modifier = Modifier
                    .alpha(if (disabled) 0.4f else 1f)
                    .widthIn(min = 76.dp)
                    .background(background, shape)
                    .border(1.dp, borderColor, shape)
                    .tappable(enabled = !disabled) { onSelect(slot.horaInicio) }
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                textAlign = TextAlign.Center,
                textDecoration = if (disabled) TextDecoration.LineThrough else null,
            )
        }
    }
}
