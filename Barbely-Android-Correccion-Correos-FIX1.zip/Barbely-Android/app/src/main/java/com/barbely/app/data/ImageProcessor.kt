package com.barbely.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import com.barbely.app.logic.IMAGE_MAX_BYTES
import com.barbely.app.logic.IMAGE_MAX_SIDE
import com.barbely.app.logic.IMAGE_MIN_QUALITY
import com.barbely.app.logic.IMAGE_MIN_SIDE
import com.barbely.app.logic.IMAGE_START_QUALITY
import com.barbely.app.logic.computeSampleSize
import com.barbely.app.logic.exifTransform
import com.barbely.app.logic.fitWithin
import com.barbely.app.logic.toDataUri
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Prepara la foto de un servicio para guardarla DENTRO del documento de Firestore (campo `imagen`)
 * como "data:image/jpeg;base64,...": se corrige la orientación, se reduce a 800 px y se comprime
 * hasta que pese menos de ~300 KB. Así no hace falta Firebase Storage (que ya no es gratuito).
 */
object ImageProcessor {

    private const val MAX_SOURCE_BYTES = 25 * 1024 * 1024

    /** Foto elegida de la galería. */
    suspend fun fromUri(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        var bytes: ByteArray? = null
        try {
            val input = context.contentResolver.openInputStream(uri)
            if (input != null) {
                bytes = input.use {
                    Http.readLimited(it, MAX_SOURCE_BYTES, "La foto es demasiado grande (máximo 25 MB).")
                }
            }
        } catch (e: IOException) {
            bytes = null
        } catch (e: SecurityException) {
            bytes = null
        }
        val data = bytes ?: throw AppException("No se pudo abrir la foto elegida.")
        encode(data)
    }

    /** Foto descargada de un enlace https:// (se guarda una copia dentro de Firestore). */
    suspend fun fromUrl(url: String): String = withContext(Dispatchers.IO) {
        encode(Http.download(url, MAX_SOURCE_BYTES))
    }

    internal fun encode(bytes: ByteArray): String {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw AppException("El archivo no es una imagen válida. Prueba con una foto JPG o PNG.")
        }

        val options = BitmapFactory.Options()
        options.inSampleSize = computeSampleSize(bounds.outWidth, bounds.outHeight, IMAGE_MAX_SIDE)
        val decoded: Bitmap = try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        } catch (e: OutOfMemoryError) {
            null
        } ?: throw AppException("No se pudo leer la foto (puede ser demasiado grande). Elige otra más pequeña.")

        val upright = flatten(orient(decoded, orientationOf(bytes)))

        var current = upright
        var quality = IMAGE_START_QUALITY
        var data = jpeg(current, quality)
        while (data.size > IMAGE_MAX_BYTES) {
            if (quality > IMAGE_MIN_QUALITY) {
                quality -= 8
            } else {
                val smaller = fitWithin(current.width, current.height, (maxOf(current.width, current.height) * 0.85f).toInt())
                if (maxOf(smaller.first, smaller.second) < IMAGE_MIN_SIDE) {
                    throw AppException("No se pudo reducir la foto lo suficiente. Elige otra más sencilla.")
                }
                current = Bitmap.createScaledBitmap(current, smaller.first, smaller.second, true)
            }
            data = jpeg(current, quality)
        }
        return toDataUri(Base64.encodeToString(data, Base64.NO_WRAP))
    }

    private fun orientationOf(bytes: ByteArray): Int =
        try {
            ExifInterface(ByteArrayInputStream(bytes))
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

    /** Gira/espeja según EXIF y deja el lado mayor en 800 px como máximo, todo en una sola operación. */
    private fun orient(source: Bitmap, orientation: Int): Bitmap {
        val transform = exifTransform(orientation)
        val turned = transform.rotation == 90f || transform.rotation == 270f
        val shownWidth = if (turned) source.height else source.width
        val shownHeight = if (turned) source.width else source.height
        val fitted = fitWithin(shownWidth, shownHeight, IMAGE_MAX_SIDE)
        val scale = fitted.first.toFloat() / shownWidth

        if (transform.isIdentity && scale >= 1f) return source

        val matrix = Matrix()
        matrix.postRotate(transform.rotation)
        if (transform.flipHorizontal) matrix.postScale(-1f, 1f)
        if (scale < 1f) matrix.postScale(scale, scale)
        return try {
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
        } catch (e: OutOfMemoryError) {
            source
        }
    }

    /** JPEG no admite transparencia: se pinta sobre fondo blanco. */
    private fun flatten(source: Bitmap): Bitmap {
        if (!source.hasAlpha()) return source
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(source, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        return result
    }

    private fun jpeg(bitmap: Bitmap, quality: Int): ByteArray {
        val output = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)
        return output.toByteArray()
    }
}
