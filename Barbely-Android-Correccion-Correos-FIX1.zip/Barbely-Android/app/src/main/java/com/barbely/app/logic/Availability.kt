package com.barbely.app.logic

import com.barbely.app.data.Schedule
import com.barbely.app.data.TimeSlot

/**
 * BARBELY — Motor de disponibilidad (equivalente a src/utils/availability.ts)
 * -----------------------------------------------------------------------
 * Genera las franjas horarias de un barbero para un día dado, del tamaño
 * de la duración del servicio, marcando como no disponibles las que se
 * solapan con una cita ya existente (las canceladas no cuentan).
 *
 * Ejemplo: si ya existe 10:00–11:00, una franja de 10:30–11:30 sale
 * marcada como no disponible.
 */

/** Rango de tiempo ocupado, en minutos desde medianoche. */
data class BusyRange(val start: Int, val end: Int)

fun rangesOverlap(aStart: Int, aEnd: Int, bStart: Int, bEnd: Int): Boolean =
    aStart < bEnd && bStart < aEnd

fun getAvailableSlots(
    weekday: Int,
    schedules: List<Schedule>,
    busy: List<BusyRange>,
    duracionMinutos: Int,
    intervalMinutos: Int = 30,
    /** Una franja que empieza antes de este minuto del día se marca como no disponible (para "hoy"). */
    earliestStart: Int = 0,
): List<TimeSlot> {
    val dayBlocks = schedules
        .filter { it.activo && it.diaSemana == weekday }
        .sortedBy { timeToMinutes(it.horaInicio) }
    if (dayBlocks.isEmpty() || duracionMinutos <= 0 || intervalMinutos <= 0) return emptyList()

    val slots = ArrayList<TimeSlot>()
    for (block in dayBlocks) {
        val blockStart = timeToMinutes(block.horaInicio)
        val blockEnd = timeToMinutes(block.horaFin)
        var start = blockStart
        while (start + duracionMinutos <= blockEnd) {
            val end = start + duracionMinutos
            val libre = busy.none { rangesOverlap(start, end, it.start, it.end) }
            slots.add(
                TimeSlot(
                    horaInicio = minutesToTime(start),
                    horaFin = minutesToTime(end),
                    disponible = libre && start >= earliestStart,
                ),
            )
            start += intervalMinutos
        }
    }
    return slots
}
